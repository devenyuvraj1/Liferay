/**
 * 
 */
package com.liferay.training.employee.web.internal.security.permission.resource;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.PermissionChecker;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.training.employee.model.Employee;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */

@Component(
		immediate = true, 
		service = EmployeePermission.class
	)
public class EmployeePermission {

	public static boolean contains(PermissionChecker permissionChecker, Employee employee,
			String actionId) throws PortalException {
		System.out.println("permissionChecker111---"+permissionChecker);
		return _employeeModelResourcePermission.contains(permissionChecker, employee, actionId);
	
	}//end method
	
	public static boolean contains(PermissionChecker permissionChecker, long employeeId, 
			String actionId) throws PortalException {
		
		return _employeeModelResourcePermission.contains(permissionChecker, employeeId, actionId);
	
	}//end method
	
	@Reference(
			target = "(model.class.name=com.liferay.training.employee.model.Employee)",
			unbind = "-"
		)
		protected void setEntryModelPermission(ModelResourcePermission<Employee> modelResourcePermission) {
		_employeeModelResourcePermission = modelResourcePermission;
		}

	
	
	
	
	private static ModelResourcePermission<Employee> _employeeModelResourcePermission;
}//end class
