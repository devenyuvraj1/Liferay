/**
 * 
 */
package com.liferay.training.employee.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.LocalizationUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.training.employee.exception.EmployeeValidationException;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.EmployeeService;
import com.liferay.training.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.training.employee.web.constants.MVCCommandNames;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
			"mvc.command.name=" + MVCCommandNames.EDIT_EMPLOYEE
		},
		service = MVCActionCommand.class
	)
public class EditEmployeeMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Employee.class.getName(), actionRequest);
	       System.out.println("Inside Edit Employee");
	       
	       long employeeId = ParamUtil.getLong(actionRequest, "employeeId");
	       
	     Map<Locale, String> employeeNameMap = LocalizationUtil.getLocalizationMap(actionRequest, "employeeName");
	  	 Map<Locale, String> genderMap = LocalizationUtil.getLocalizationMap(actionRequest, "gender");
	  	 Map<Locale, String> designationMap = LocalizationUtil.getLocalizationMap(actionRequest, "designation");
	  	 Map<Locale, String> descriptionMap = LocalizationUtil.getLocalizationMap(actionRequest, "description");

	  	 Date joiningDate = ParamUtil.getDate(actionRequest, "joiningDate", DateFormatFactoryUtil.getDate(actionRequest.getLocale()));
	  	
	  	 try {
	  		_employeeService.updateEmployee(employeeId, employeeNameMap, genderMap, designationMap, descriptionMap, joiningDate, serviceContext);
	  		 
	  	       // Set the success message.
				SessionMessages.add(actionRequest, "employeeUpdated");
				
				sendRedirect(actionRequest, actionResponse);
	  	 }
		
		  catch (EmployeeValidationException ave) { //ave.printStackTrace();
		  
		  // Get error messages from the service layer. 
		  ave.getErrors().forEach(key ->SessionErrors.add(actionRequest, key));
		  
		  actionResponse.setRenderParameter("mvcRenderCommandName",
		  MVCCommandNames.EDIT_EMPLOYEE);
		  
		  }
		 
	  	catch (PortalException pe) {
			//pe.printStackTrace();
			
			// Set error messages from the service layer.
			SessionErrors.add(actionRequest, "serviceErrorDetails", pe);

			actionResponse.setRenderParameter("mvcRenderCommandName", MVCCommandNames.EDIT_EMPLOYEE);			
		}
		
	}//end method
	
	
	@Reference
	protected EmployeeService _employeeService;

}//end class
