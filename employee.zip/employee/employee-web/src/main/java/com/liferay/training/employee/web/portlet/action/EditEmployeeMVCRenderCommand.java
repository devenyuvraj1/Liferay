/**
 * 
 */
package com.liferay.training.employee.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.EmployeeService;
import com.liferay.training.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.training.employee.web.constants.MVCCommandNames;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
			"mvc.command.name=" + MVCCommandNames.EDIT_EMPLOYEE
		}, 
		service = MVCRenderCommand.class
	)
public class EditEmployeeMVCRenderCommand implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		Employee employee = null;
		
		Long employeeId = ParamUtil.getLong(renderRequest, "employeeId", 0);
		
		if (employeeId > 0) {
			try {
				// Call the service to get the assignment for editing.
				employee = _employeeService.getEmployee(employeeId);
			}
			/*
			 * catch (NoSuchAssignmentException nsae) { nsae.printStackTrace(); }
			 */
			catch (PortalException pe) {
				pe.printStackTrace();
			}
		}
		
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);

		// Set back icon visible.
		PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();

		portletDisplay.setShowBackIcon(true);
		String redirect = renderRequest.getParameter("redirect");
		portletDisplay.setURLBack(redirect);
		
		renderRequest.setAttribute("employee", employee);
		renderRequest.setAttribute("employeeClass", Employee.class);

		return "/employee/edit_employee.jsp";
		

	}//end method
	
	
	@Reference
	private EmployeeService _employeeService;

}//end class
