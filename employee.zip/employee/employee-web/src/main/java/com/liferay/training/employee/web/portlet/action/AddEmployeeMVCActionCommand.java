/**
 * 
 */
package com.liferay.training.employee.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.LocalizationUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.employee.exception.EmployeeValidationException;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.EmployeeService;
import com.liferay.training.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.training.employee.web.constants.MVCCommandNames;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
			"mvc.command.name=" + MVCCommandNames.ADD_EMPLOYEE
		},
		service = MVCActionCommand.class
	)
public class AddEmployeeMVCActionCommand extends BaseMVCActionCommand{

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Employee.class.getName(), actionRequest);
       System.out.println("Inside Add Employee");
	 // Get parameters from the request.
	// Use LocalizationUtil to get a localized parameter.
	 Map<Locale, String> employeeNameMap = LocalizationUtil.getLocalizationMap(actionRequest, "employeeName");
	 Map<Locale, String> genderMap = LocalizationUtil.getLocalizationMap(actionRequest, "gender");
	 Map<Locale, String> designationMap = LocalizationUtil.getLocalizationMap(actionRequest, "designation");
	 Map<Locale, String> descriptionMap = LocalizationUtil.getLocalizationMap(actionRequest, "description");

	 Date joiningDate = ParamUtil.getDate(actionRequest, "joiningDate", DateFormatFactoryUtil.getDate(actionRequest.getLocale()));
		
	 try {
			// Call the service to add a a new employee.
		 System.out.println("1");
		 System.out.println("employeeNameMap--"+employeeNameMap);
		    _employeeService.addEmployee(themeDisplay.getScopeGroupId(), employeeNameMap, genderMap, designationMap, descriptionMap, joiningDate, serviceContext);
		    System.out.println("2");
			// Set the success message.
			SessionMessages.add(actionRequest, "employeeAdded");
			System.out.println("3");
			sendRedirect(actionRequest, actionResponse);
		}
		
		catch (EmployeeValidationException ave) {
			  
		  
		  // Get error messages from the service layer. 
			ave.getErrors().forEach(key ->SessionErrors.add(actionRequest, key));
		  
		  actionResponse.setRenderParameter("mvcRenderCommandName",MVCCommandNames.EDIT_EMPLOYEE);
		
     }
	 catch (PortalException pe) {
			System.out.println("inside pe ex--"+pe.getMessage());
			//pe.printStackTrace();

			// Set error messages from the service layer.
			SessionErrors.add(actionRequest, "serviceErrorDetails", pe);

			actionResponse.setRenderParameter("mvcRenderCommandName", MVCCommandNames.EDIT_EMPLOYEE);			
		}
	 
	 
	}//end method
	
	
	@Reference
	protected EmployeeService _employeeService;

}//end class
