package com.liferay.training.employee.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.training.employee.service.EmployeeService;
import com.liferay.training.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.training.employee.web.constants.MVCCommandNames;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
			"mvc.command.name=" + MVCCommandNames.DELETE_EMPLOYEE
		},
		service = MVCActionCommand.class
	)
public class DeleteEmployeeMVCActionCommand  extends BaseMVCActionCommand{

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		long employeeId = ParamUtil.getLong(actionRequest, "employeeId");
		
		try {
			// Call service to delete the employee.
			_employeeService.deleteEmployee(employeeId);
			
			// Set success message.
			SessionMessages.add(actionRequest, "employeeDeleted");
		}
		catch (PortalException pe) {
			//pe.printStackTrace();
			// Set error messages from the service layer.
			SessionErrors.add(actionRequest, "serviceErrorDetails", pe);
		}
	}//end method
	
	@Reference
	protected EmployeeService _employeeService;

}//end class
