/**
 * 
 */
package com.liferay.training.employee.web.portlet.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.theme.PortletDisplay;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.DateFormatFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.EmployeeService;
import com.liferay.training.employee.web.constants.EmployeeWebPortletKeys;
import com.liferay.training.employee.web.constants.MVCCommandNames;

import java.text.DateFormat;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */


@Component(
		immediate = true,
		property = {
			"javax.portlet.name=" + EmployeeWebPortletKeys.EMPLOYEEWEB,
			"mvc.command.name=" + MVCCommandNames.VIEW_EMPLOYEE
		},
		service = MVCRenderCommand.class
	)
public class ViewSingleEmployeeMVCRenderCommand  implements MVCRenderCommand{

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long employeeId = ParamUtil.getLong(renderRequest, "employeeId", 0);
		System.out.println("employeeId---"+employeeId);
		
		try {
			// Call the service to get the assignment.
			Employee employee = _employeeService.getEmployee(employeeId);
			DateFormat dateFormat = DateFormatFactoryUtil.getSimpleDateFormat("EEEEE, MMMMM dd, yyyy", renderRequest.getLocale());

			// Set attributes to the request.
			// Set attributes to the request.
			System.out.println("dateFormat.format(employee.getJoiningDate())--"+dateFormat.format(employee.getJoiningDate()));
			renderRequest.setAttribute("employee", employee);
			renderRequest.setAttribute("joiningDate", dateFormat.format(employee.getJoiningDate()));
			renderRequest.setAttribute("createDate", dateFormat.format(employee.getCreateDate()));

			// Set back icon visible.
			PortletDisplay portletDisplay = themeDisplay.getPortletDisplay();

			String redirect = renderRequest.getParameter("redirect");

			portletDisplay.setShowBackIcon(true);
			portletDisplay.setURLBack(redirect);
			
			return "/employee/view_employee.jsp";
		}
		catch (PortalException pe) {
			throw new PortletException(pe);
		}
		
	}//end method
	
	@Reference
	private EmployeeService _employeeService;

	@Reference
	private Portal _portal;

	@Reference
	private UserLocalService _userLocalService;

}//end class
