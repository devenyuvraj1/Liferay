package com.liferay.training.employee.web.constants;

/**
 * @author DK00631421
 */
public class EmployeeWebPortletKeys {

	public static final String EMPLOYEEWEB =
		"com_liferay_training_employee_web_EmployeeWebPortlet";

}