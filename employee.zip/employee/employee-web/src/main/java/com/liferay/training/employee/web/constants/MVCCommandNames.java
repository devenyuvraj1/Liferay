package com.liferay.training.employee.web.constants;

/**
 *  @author DK00631421
 *
 */
public class MVCCommandNames {

	public static final String ADD_EMPLOYEE = "/employee/employee/add";
	public static final String DELETE_EMPLOYEE = "/employee/employee/delete";
	public static final String EDIT_EMPLOYEE = "/employee/employee/edit";
	public static final String VIEW_EMPLOYEE = "/employee/employee/view";
	public static final String VIEW_EMPLOYEES = "/employee/employees/view";
	

}