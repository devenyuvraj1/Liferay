/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.employee.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Group;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.base.EmployeeLocalServiceBaseImpl;
import com.liferay.training.employee.validator.EmployeeValidator;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * The implementation of the employee local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.liferay.training.employee.service.EmployeeLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author devendra
 * @see EmployeeLocalServiceBaseImpl
 */
@Component(
	property = "model.class.name=com.liferay.training.employee.model.Employee",
	service = AopService.class
)
public class EmployeeLocalServiceImpl extends EmployeeLocalServiceBaseImpl {

	/* (non-Javadoc)
	 * @see com.liferay.training.employee.service.base.EmployeeLocalServiceBaseImpl#addEmployee(com.liferay.training.employee.model.Employee)
	 */

	public Employee addEmployee(long groupId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		System.out.println("Inside EmployeeLocalServiceImpl");
		
		// Validate employee parameters.
		_employeeValidator.validate(employeeNameMap, genderMap, designationMap, descriptionMap, joiningDate);
		
		// Get group and user.
		Group group = groupLocalService.getGroup(groupId);
		System.out.println("Inside EmployeeLocalServiceImpl 0");
		System.out.println("Inside EmployeeLocalServiceImpl"+group);
		long userId = serviceContext.getUserId();
		User user = userLocalService.getUser(userId);
		System.out.println("Inside EmployeeLocalServiceImpl 1");
		// Generate primary key for the employee
		long employeeId = counterLocalService.increment(Employee.class.getName());
		System.out.println("Inside EmployeeLocalServiceImpl 2"+employeeId);
		// Create assigment. This doesn't yet persist the entity.
		Employee employee = createEmployee(employeeId);
		
		// Populate fields.
		employee.setCompanyId(group.getCompanyId());
		employee.setCreateDate(serviceContext.getCreateDate(new Date()));
		employee.setJoiningDate(joiningDate);
		employee.setEmployeeNameMap(employeeNameMap);
		employee.setGenderMap(genderMap);
		employee.setDesignationMap(designationMap);
		employee.setDescriptionMap(descriptionMap);
		employee.setGroupId(groupId);
		employee.setModifiedDate(serviceContext.getModifiedDate(new Date()));
		employee.setUserId(userId);
		employee.setUserName(user.getScreenName());
		
		// Add permission resources.
		boolean portletActions = true;
		boolean addGroupPermissions = true;
		boolean addGuestPermissions = true;
		
		System.out.println("Inside EmployeeLocalServiceImpl 3");
		try {
			
			resourceLocalService.addResources(group.getCompanyId(), groupId, userId, Employee.class.getName(), employee.getEmployeeId(), portletActions, addGroupPermissions, addGuestPermissions);
		}catch(Exception e) {
			System.out.println("Inside error mes---"+e.getMessage());
		}
		
		System.out.println("Inside EmployeeLocalServiceImpl 4");
		
		return super.addEmployee(employee);
	}
	
	
	public Employee updateEmployee(long employeeId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		
		_employeeValidator.validate(employeeNameMap, genderMap, designationMap, descriptionMap, joiningDate);
		
		// Get the Employee by id.
		Employee employee = getEmployee(employeeId);
		
		// Set updated fields and modification date.
		employee.setModifiedDate(new Date());
		employee.setEmployeeNameMap(employeeNameMap);
		employee.setGenderMap(genderMap);
		employee.setDesignationMap(designationMap);
		employee.setDescriptionMap(descriptionMap);
		employee.setJoiningDate(joiningDate);
		
		employee = super.updateEmployee(employee);
		
		return employee;
	}
	
	

	
	public List<Employee> getEmployeesByGroupId(long groupId) {
		return employeePersistence.findByGroupId(groupId);
	}

	public List<Employee> getEmployeesByGroupId(long groupId, int start, int end) {
		return employeePersistence.findByGroupId(groupId, start, end);
	}

	public List<Employee> getEmployeesByGroupId(long groupId, int start, int end, OrderByComparator<Employee> orderByComparator) {
		return employeePersistence.findByGroupId(groupId, start, end, orderByComparator);
	}

	public List<Employee> getEmployeesByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Employee> orderByComparator) {
		return employeeLocalService.dynamicQuery(getKeywordSearchDynamicQuery(groupId, keywords), start, end, orderByComparator);
	}
	
	public long getEmployeesCountByKeywords(long groupId, String keywords) {
		return employeeLocalService.dynamicQueryCount(getKeywordSearchDynamicQuery(groupId, keywords));
	}
	
	private DynamicQuery getKeywordSearchDynamicQuery(long groupId, String keywords) {

		DynamicQuery dynamicQuery = dynamicQuery().add(RestrictionsFactoryUtil.eq("groupId", groupId));

		if (Validator.isNotNull(keywords)) {
			Disjunction disjunctionQuery = RestrictionsFactoryUtil.disjunction();

			disjunctionQuery.add(RestrictionsFactoryUtil.like("employeeName", "%" + keywords + "%"));
			disjunctionQuery.add(RestrictionsFactoryUtil.like("gender", "%" + keywords + "%"));
			dynamicQuery.add(disjunctionQuery);
		}

		return dynamicQuery;
	}

	
	
	public Employee deleteEmployee(Employee employee) throws PortalException {
		resourceLocalService.deleteResource(employee, ResourceConstants.SCOPE_INDIVIDUAL);
		return super.deleteEmployee(employee);
	}
	
	@Override
	public Employee addEmployee(Employee employee) {
		throw new UnsupportedOperationException("Not supported.");
	}

	
	@Override
	public Employee updateEmployee(Employee employee) {
		throw new UnsupportedOperationException("Not supported.");
	}

	
	@Reference
	EmployeeValidator _employeeValidator;
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Use <code>com.liferay.training.employee.service.EmployeeLocalService</code> via injection or a <code>org.osgi.util.tracker.ServiceTracker</code> or use <code>com.liferay.training.employee.service.EmployeeLocalServiceUtil</code>.
	 */
}