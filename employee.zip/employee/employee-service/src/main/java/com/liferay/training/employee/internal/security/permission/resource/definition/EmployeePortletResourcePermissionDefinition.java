/**
 * 
 */
package com.liferay.training.employee.internal.security.permission.resource.definition;

import com.liferay.exportimport.kernel.staging.permission.StagingPermission;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.StagedPortletPermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.definition.PortletResourcePermissionDefinition;
import com.liferay.training.employee.constants.EmployeeConstants;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */

@Component(
		immediate = true, 
		service = PortletResourcePermissionDefinition.class
	)
public class EmployeePortletResourcePermissionDefinition  implements PortletResourcePermissionDefinition {

	@Override
	public PortletResourcePermissionLogic[] getPortletResourcePermissionLogics() {
		return new PortletResourcePermissionLogic[] {
				new StagedPortletPermissionLogic(
						_stagingPermission,
						"com_liferay_training_employee_web_EmployeeWebPortlet")
		};
	}

	@Override
	public String getResourceName() {
		return EmployeeConstants.RESOURCE_NAME;
	}
	
	@Reference
	private StagingPermission _stagingPermission;


}//end class
