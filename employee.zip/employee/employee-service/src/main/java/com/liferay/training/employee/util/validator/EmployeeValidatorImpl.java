/**
 * 
 */
package com.liferay.training.employee.util.validator;

import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.MapUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.training.employee.exception.EmployeeValidationException;
import com.liferay.training.employee.validator.EmployeeValidator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;


/**
 * @author DK00631421
 *
 */
@Component(
		immediate = true, 
		service = EmployeeValidator.class
	)
public class EmployeeValidatorImpl implements EmployeeValidator{

	@Override
	public void validate(Map<Locale, String> employeeNameMap, Map<Locale, String> genderMap,
			Map<Locale, String> designationMap, Map<Locale, String> descriptionMap, Date joiningDate)
			throws EmployeeValidationException {
		
		List<String> errors = new ArrayList<>();
		
		if (!isEmployeeValid(employeeNameMap, genderMap, designationMap,descriptionMap,joiningDate, errors)) {
			throw new EmployeeValidationException(errors);
		}
		
	}//end method

	private boolean isEmployeeValid(Map<Locale, String> employeeNameMap, Map<Locale, String> genderMap,
			Map<Locale, String> designationMap, Map<Locale, String> descriptionMap, Date joiningDate,
			List<String> errors) {
		boolean result = true;

		result &= isEmployeeNameValid(employeeNameMap, errors);
		result &= isGenderValid(genderMap, errors);
		result &= isDesignationValid(designationMap, errors);
		result &= isDescriptionValid(descriptionMap, errors);
		result &= isJoiningDateValid(joiningDate, errors);

		return result;
	}

	private boolean isJoiningDateValid(Date joiningDate, List<String> errors) {
		boolean result = true;


		if (Validator.isNull(joiningDate)) {
			errors.add("employeeJoiningDateEmpty");
			result = false;
		}
		return result;
	}

	private boolean isDescriptionValid(Map<Locale, String> descriptionMap, List<String> errors) {
		boolean result = true;

		// Verify the map has something
		if (MapUtil.isEmpty(descriptionMap)) {
			errors.add("employeeDescriptionEmpty");
			result = false;
		}
		else {
			// Get the default locale
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			if ((Validator.isBlank(descriptionMap.get(defaultLocale)))) {
				errors.add("employeeDescriptionEmpty");
				result = false;
			}
		}
		return result;
	}

	private boolean isDesignationValid(Map<Locale, String> designationMap, List<String> errors) {
		boolean result = true;

		// Verify the map has something
		if (MapUtil.isEmpty(designationMap)) {
			errors.add("employeeDesignationEmpty");
			result = false;
		}
		else {
			// Get the default locale
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			if ((Validator.isBlank(designationMap.get(defaultLocale)))) {
				errors.add("employeeDesignationEmpty");
				result = false;
			}
		}
		return result;
	}

	private boolean isGenderValid(Map<Locale, String> genderMap, List<String> errors) {
		boolean result = true;

		// Verify the map has something
		if (MapUtil.isEmpty(genderMap)) {
			errors.add("employeeGenderEmpty");
			result = false;
		}
		else {
			// Get the default locale
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			if ((Validator.isBlank(genderMap.get(defaultLocale)))) {
				errors.add("employeeGenderEmpty");
				result = false;
			}
		}
		return result;
	}

	private boolean isEmployeeNameValid(Map<Locale, String> employeeNameMap, List<String> errors) {
		boolean result = true;

		// Verify the map has something
		if (MapUtil.isEmpty(employeeNameMap)) {
			errors.add("employeeNameEmpty");
			result = false;
		}
		else {
			// Get the default locale
			Locale defaultLocale = LocaleUtil.getSiteDefault();
			if ((Validator.isBlank(employeeNameMap.get(defaultLocale)))) {
				errors.add("employeeNameEmpty");
				result = false;
			}
		}
		return result;
	}

}
