/**
 * 
 */
package com.liferay.training.employee.internal.security.permission.resource.definition;

import com.liferay.exportimport.kernel.staging.permission.StagingPermission;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.StagedModelPermissionLogic;
import com.liferay.portal.kernel.security.permission.resource.definition.ModelResourcePermissionDefinition;
import com.liferay.portal.kernel.service.GroupLocalService;
import com.liferay.portal.kernel.workflow.permission.WorkflowPermission;
import com.liferay.training.employee.constants.EmployeeConstants;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.EmployeeLocalService;

import java.util.function.Consumer;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author DK00631421
 *
 */
@Component(
		immediate = true, 
		service = ModelResourcePermissionDefinition.class
	)
public class EmployeeModelResourcePermissionDefinition implements ModelResourcePermissionDefinition<Employee>{

	@Override
	public Employee getModel(long employeeId) throws PortalException {
		return _employeeLocalService.getEmployee(employeeId);
	}

	@Override
	public Class<Employee> getModelClass() {
		return Employee.class;
	}

	@Override
	public PortletResourcePermission getPortletResourcePermission() {
		return _portletResourcePermission;
	}

	@Override
	public long getPrimaryKey(Employee t) {
		return t.getEmployeeId();
	}

	@Override
	public void registerModelResourcePermissionLogics(ModelResourcePermission<Employee> modelResourcePermission,
			Consumer<ModelResourcePermissionLogic<Employee>> modelResourcePermissionLogicConsumer) {
		modelResourcePermissionLogicConsumer.accept(
		new StagedModelPermissionLogic<>(
				_stagingPermission,"com_liferay_training_employee_web_EmployeeWebPortlet",
				Employee::getEmployeeId
				));
		
	}
	
	@Reference
	private EmployeeLocalService _employeeLocalService;
	
	@Reference
	private GroupLocalService _groupLocalService;
	
	@Reference(target="(resource.name="+EmployeeConstants.RESOURCE_NAME+")")
	private PortletResourcePermission _portletResourcePermission;
	
	@Reference
	private StagingPermission _stagingPermission;
	
	@Reference
	private WorkflowPermission _workflowPermission;

}//end class
