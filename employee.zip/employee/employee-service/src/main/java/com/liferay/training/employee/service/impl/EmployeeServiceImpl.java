/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.employee.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.ActionKeys;
import com.liferay.portal.kernel.security.permission.resource.ModelResourcePermission;
import com.liferay.portal.kernel.security.permission.resource.PortletResourcePermission;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.training.employee.constants.EmployeeConstants;
import com.liferay.training.employee.model.Employee;
import com.liferay.training.employee.service.base.EmployeeServiceBaseImpl;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferencePolicy;
import org.osgi.service.component.annotations.ReferencePolicyOption;

/**
 * The implementation of the employee remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.liferay.training.employee.service.EmployeeService</code> interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author devendra
 * @see EmployeeServiceBaseImpl
 */
@Component(
	property = {
		"json.web.service.context.name=employee",
		"json.web.service.context.path=Employee"
	},
	service = AopService.class
)
public class EmployeeServiceImpl extends EmployeeServiceBaseImpl {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Always use <code>com.liferay.training.employee.service.EmployeeServiceUtil</code> to access the employee remote service.
	 */
	
	
	public Employee addEmployee(long groupId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		System.out.println("inside EmployeeServiceImpl calss");
		
		// Check permissions.
		_portletResourcePermission.check(getPermissionChecker(), serviceContext.getScopeGroupId(),ActionKeys.ADD_ENTRY);
				
		
		return employeeLocalService.addEmployee(groupId,employeeNameMap,genderMap,designationMap,descriptionMap,joiningDate,serviceContext);
	}
	
	public Employee updateEmployee(long employeeId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		
		// Check permissions.
		_employeeModelResourcePermission.check(getPermissionChecker(), employeeId, ActionKeys.UPDATE);

		
		return employeeLocalService.updateEmployee(employeeId,employeeNameMap,genderMap,designationMap,descriptionMap,joiningDate,serviceContext);
	}
	
	public Employee deleteEmployee(long employeeId) throws PortalException {
		// Check permissions.
		_employeeModelResourcePermission.check(getPermissionChecker(), employeeId, ActionKeys.DELETE);
				
		Employee employee = employeeLocalService.getEmployee(employeeId);
		
		return employeeLocalService.deleteEmployee(employee);
		
	}
	
	public Employee getEmployee(long employeeId) throws PortalException {
		Employee employee = employeeLocalService.getEmployee(employeeId);

		// Check permissions.
		_employeeModelResourcePermission.check(getPermissionChecker(), employee, ActionKeys.VIEW);

		return employee;
	}
	
	public List<Employee> getEmployeesByGroupId(long groupId) {
		return employeePersistence.filterFindByGroupId(groupId);
	}
	
	public List<Employee> getEmployeesByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Employee> orderByComparator) {
		return employeeLocalService.getEmployeesByKeywords(groupId, keywords, start, end, orderByComparator);
	}
	
	public long getEmployeesCountByKeywords(long groupId, String keywords) {
		return employeeLocalService.getEmployeesCountByKeywords(groupId, keywords);
	}
	
	
	
	
	
	
	
	
	
	
	
	@Reference(
			policy = ReferencePolicy.DYNAMIC,
			policyOption = ReferencePolicyOption.GREEDY,
			target = "(model.class.name=com.liferay.training.employee.model.Employee)"
		)
		private volatile ModelResourcePermission<Employee> _employeeModelResourcePermission;
			
		@Reference(
			policy = ReferencePolicy.DYNAMIC,
			policyOption = ReferencePolicyOption.GREEDY,
			target = "(resource.name=" + EmployeeConstants.RESOURCE_NAME + ")"
		)
	
	
	
	private volatile PortletResourcePermission _portletResourcePermission;
	
}