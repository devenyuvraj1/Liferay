/**
 * 
 */
package com.liferay.training.employee.validator;

import com.liferay.training.employee.exception.EmployeeValidationException;

import java.util.Date;
import java.util.Locale;
import java.util.Map;


/**
 * @author DK00631421
 *
 */
public interface EmployeeValidator {
	/**
	 * Validates an employee
	 * 
	 * @param employeeNameMap
	 * @param genderMap
	 * @param designationMap
	 * @param descriptionMap
	 * @param joiningDate
	 * @throws EmployeeValidatorException
	 */
	public void validate(Map<Locale, String> employeeNameMap,Map<Locale, String> genderMap,Map<Locale, String> designationMap,Map<Locale, String> descriptionMap, Date joiningDate) throws EmployeeValidationException;
}
