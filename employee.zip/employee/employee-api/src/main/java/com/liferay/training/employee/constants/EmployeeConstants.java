/**
 * 
 */
package com.liferay.training.employee.constants;

/**
 * @author DK00631421
 *
 */
public class EmployeeConstants {
	public static final String RESOURCE_NAME = "com.liferay.training.employee.model";
}
