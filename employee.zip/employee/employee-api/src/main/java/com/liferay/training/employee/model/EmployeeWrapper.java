/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.employee.model;

import com.liferay.exportimport.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This class is a wrapper for {@link Employee}.
 * </p>
 *
 * @author devendra
 * @see Employee
 * @generated
 */
@ProviderType
public class EmployeeWrapper
	extends BaseModelWrapper<Employee>
	implements Employee, ModelWrapper<Employee> {

	public EmployeeWrapper(Employee employee) {
		super(employee);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("employeeId", getEmployeeId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("employeeName", getEmployeeName());
		attributes.put("gender", getGender());
		attributes.put("designation", getDesignation());
		attributes.put("description", getDescription());
		attributes.put("joiningDate", getJoiningDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long employeeId = (Long)attributes.get("employeeId");

		if (employeeId != null) {
			setEmployeeId(employeeId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String employeeName = (String)attributes.get("employeeName");

		if (employeeName != null) {
			setEmployeeName(employeeName);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String designation = (String)attributes.get("designation");

		if (designation != null) {
			setDesignation(designation);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Date joiningDate = (Date)attributes.get("joiningDate");

		if (joiningDate != null) {
			setJoiningDate(joiningDate);
		}
	}

	@Override
	public String[] getAvailableLanguageIds() {
		return model.getAvailableLanguageIds();
	}

	/**
	 * Returns the company ID of this employee.
	 *
	 * @return the company ID of this employee
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the create date of this employee.
	 *
	 * @return the create date of this employee
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	@Override
	public String getDefaultLanguageId() {
		return model.getDefaultLanguageId();
	}

	/**
	 * Returns the description of this employee.
	 *
	 * @return the description of this employee
	 */
	@Override
	public String getDescription() {
		return model.getDescription();
	}

	/**
	 * Returns the localized description of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param locale the locale of the language
	 * @return the localized description of this employee
	 */
	@Override
	public String getDescription(java.util.Locale locale) {
		return model.getDescription(locale);
	}

	/**
	 * Returns the localized description of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param locale the local of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized description of this employee. If <code>useDefault</code> is <code>false</code> and no localization exists for the requested language, an empty string will be returned.
	 */
	@Override
	public String getDescription(java.util.Locale locale, boolean useDefault) {
		return model.getDescription(locale, useDefault);
	}

	/**
	 * Returns the localized description of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @return the localized description of this employee
	 */
	@Override
	public String getDescription(String languageId) {
		return model.getDescription(languageId);
	}

	/**
	 * Returns the localized description of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized description of this employee
	 */
	@Override
	public String getDescription(String languageId, boolean useDefault) {
		return model.getDescription(languageId, useDefault);
	}

	@Override
	public String getDescriptionCurrentLanguageId() {
		return model.getDescriptionCurrentLanguageId();
	}

	@Override
	public String getDescriptionCurrentValue() {
		return model.getDescriptionCurrentValue();
	}

	/**
	 * Returns a map of the locales and localized descriptions of this employee.
	 *
	 * @return the locales and localized descriptions of this employee
	 */
	@Override
	public Map<java.util.Locale, String> getDescriptionMap() {
		return model.getDescriptionMap();
	}

	/**
	 * Returns the designation of this employee.
	 *
	 * @return the designation of this employee
	 */
	@Override
	public String getDesignation() {
		return model.getDesignation();
	}

	/**
	 * Returns the localized designation of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param locale the locale of the language
	 * @return the localized designation of this employee
	 */
	@Override
	public String getDesignation(java.util.Locale locale) {
		return model.getDesignation(locale);
	}

	/**
	 * Returns the localized designation of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param locale the local of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized designation of this employee. If <code>useDefault</code> is <code>false</code> and no localization exists for the requested language, an empty string will be returned.
	 */
	@Override
	public String getDesignation(java.util.Locale locale, boolean useDefault) {
		return model.getDesignation(locale, useDefault);
	}

	/**
	 * Returns the localized designation of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @return the localized designation of this employee
	 */
	@Override
	public String getDesignation(String languageId) {
		return model.getDesignation(languageId);
	}

	/**
	 * Returns the localized designation of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized designation of this employee
	 */
	@Override
	public String getDesignation(String languageId, boolean useDefault) {
		return model.getDesignation(languageId, useDefault);
	}

	@Override
	public String getDesignationCurrentLanguageId() {
		return model.getDesignationCurrentLanguageId();
	}

	@Override
	public String getDesignationCurrentValue() {
		return model.getDesignationCurrentValue();
	}

	/**
	 * Returns a map of the locales and localized designations of this employee.
	 *
	 * @return the locales and localized designations of this employee
	 */
	@Override
	public Map<java.util.Locale, String> getDesignationMap() {
		return model.getDesignationMap();
	}

	/**
	 * Returns the employee ID of this employee.
	 *
	 * @return the employee ID of this employee
	 */
	@Override
	public long getEmployeeId() {
		return model.getEmployeeId();
	}

	/**
	 * Returns the employee name of this employee.
	 *
	 * @return the employee name of this employee
	 */
	@Override
	public String getEmployeeName() {
		return model.getEmployeeName();
	}

	/**
	 * Returns the localized employee name of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param locale the locale of the language
	 * @return the localized employee name of this employee
	 */
	@Override
	public String getEmployeeName(java.util.Locale locale) {
		return model.getEmployeeName(locale);
	}

	/**
	 * Returns the localized employee name of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param locale the local of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized employee name of this employee. If <code>useDefault</code> is <code>false</code> and no localization exists for the requested language, an empty string will be returned.
	 */
	@Override
	public String getEmployeeName(java.util.Locale locale, boolean useDefault) {
		return model.getEmployeeName(locale, useDefault);
	}

	/**
	 * Returns the localized employee name of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @return the localized employee name of this employee
	 */
	@Override
	public String getEmployeeName(String languageId) {
		return model.getEmployeeName(languageId);
	}

	/**
	 * Returns the localized employee name of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized employee name of this employee
	 */
	@Override
	public String getEmployeeName(String languageId, boolean useDefault) {
		return model.getEmployeeName(languageId, useDefault);
	}

	@Override
	public String getEmployeeNameCurrentLanguageId() {
		return model.getEmployeeNameCurrentLanguageId();
	}

	@Override
	public String getEmployeeNameCurrentValue() {
		return model.getEmployeeNameCurrentValue();
	}

	/**
	 * Returns a map of the locales and localized employee names of this employee.
	 *
	 * @return the locales and localized employee names of this employee
	 */
	@Override
	public Map<java.util.Locale, String> getEmployeeNameMap() {
		return model.getEmployeeNameMap();
	}

	/**
	 * Returns the gender of this employee.
	 *
	 * @return the gender of this employee
	 */
	@Override
	public String getGender() {
		return model.getGender();
	}

	/**
	 * Returns the localized gender of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param locale the locale of the language
	 * @return the localized gender of this employee
	 */
	@Override
	public String getGender(java.util.Locale locale) {
		return model.getGender(locale);
	}

	/**
	 * Returns the localized gender of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param locale the local of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized gender of this employee. If <code>useDefault</code> is <code>false</code> and no localization exists for the requested language, an empty string will be returned.
	 */
	@Override
	public String getGender(java.util.Locale locale, boolean useDefault) {
		return model.getGender(locale, useDefault);
	}

	/**
	 * Returns the localized gender of this employee in the language. Uses the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @return the localized gender of this employee
	 */
	@Override
	public String getGender(String languageId) {
		return model.getGender(languageId);
	}

	/**
	 * Returns the localized gender of this employee in the language, optionally using the default language if no localization exists for the requested language.
	 *
	 * @param languageId the ID of the language
	 * @param useDefault whether to use the default language if no localization exists for the requested language
	 * @return the localized gender of this employee
	 */
	@Override
	public String getGender(String languageId, boolean useDefault) {
		return model.getGender(languageId, useDefault);
	}

	@Override
	public String getGenderCurrentLanguageId() {
		return model.getGenderCurrentLanguageId();
	}

	@Override
	public String getGenderCurrentValue() {
		return model.getGenderCurrentValue();
	}

	/**
	 * Returns a map of the locales and localized genders of this employee.
	 *
	 * @return the locales and localized genders of this employee
	 */
	@Override
	public Map<java.util.Locale, String> getGenderMap() {
		return model.getGenderMap();
	}

	/**
	 * Returns the group ID of this employee.
	 *
	 * @return the group ID of this employee
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the joining date of this employee.
	 *
	 * @return the joining date of this employee
	 */
	@Override
	public Date getJoiningDate() {
		return model.getJoiningDate();
	}

	/**
	 * Returns the modified date of this employee.
	 *
	 * @return the modified date of this employee
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the primary key of this employee.
	 *
	 * @return the primary key of this employee
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the user ID of this employee.
	 *
	 * @return the user ID of this employee
	 */
	@Override
	public long getUserId() {
		return model.getUserId();
	}

	/**
	 * Returns the user name of this employee.
	 *
	 * @return the user name of this employee
	 */
	@Override
	public String getUserName() {
		return model.getUserName();
	}

	/**
	 * Returns the user uuid of this employee.
	 *
	 * @return the user uuid of this employee
	 */
	@Override
	public String getUserUuid() {
		return model.getUserUuid();
	}

	/**
	 * Returns the uuid of this employee.
	 *
	 * @return the uuid of this employee
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	@Override
	public void prepareLocalizedFieldsForImport()
		throws com.liferay.portal.kernel.exception.LocaleException {

		model.prepareLocalizedFieldsForImport();
	}

	@Override
	public void prepareLocalizedFieldsForImport(
			java.util.Locale defaultImportLocale)
		throws com.liferay.portal.kernel.exception.LocaleException {

		model.prepareLocalizedFieldsForImport(defaultImportLocale);
	}

	/**
	 * Sets the company ID of this employee.
	 *
	 * @param companyId the company ID of this employee
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the create date of this employee.
	 *
	 * @param createDate the create date of this employee
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the description of this employee.
	 *
	 * @param description the description of this employee
	 */
	@Override
	public void setDescription(String description) {
		model.setDescription(description);
	}

	/**
	 * Sets the localized description of this employee in the language.
	 *
	 * @param description the localized description of this employee
	 * @param locale the locale of the language
	 */
	@Override
	public void setDescription(String description, java.util.Locale locale) {
		model.setDescription(description, locale);
	}

	/**
	 * Sets the localized description of this employee in the language, and sets the default locale.
	 *
	 * @param description the localized description of this employee
	 * @param locale the locale of the language
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setDescription(
		String description, java.util.Locale locale,
		java.util.Locale defaultLocale) {

		model.setDescription(description, locale, defaultLocale);
	}

	@Override
	public void setDescriptionCurrentLanguageId(String languageId) {
		model.setDescriptionCurrentLanguageId(languageId);
	}

	/**
	 * Sets the localized descriptions of this employee from the map of locales and localized descriptions.
	 *
	 * @param descriptionMap the locales and localized descriptions of this employee
	 */
	@Override
	public void setDescriptionMap(
		Map<java.util.Locale, String> descriptionMap) {

		model.setDescriptionMap(descriptionMap);
	}

	/**
	 * Sets the localized descriptions of this employee from the map of locales and localized descriptions, and sets the default locale.
	 *
	 * @param descriptionMap the locales and localized descriptions of this employee
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setDescriptionMap(
		Map<java.util.Locale, String> descriptionMap,
		java.util.Locale defaultLocale) {

		model.setDescriptionMap(descriptionMap, defaultLocale);
	}

	/**
	 * Sets the designation of this employee.
	 *
	 * @param designation the designation of this employee
	 */
	@Override
	public void setDesignation(String designation) {
		model.setDesignation(designation);
	}

	/**
	 * Sets the localized designation of this employee in the language.
	 *
	 * @param designation the localized designation of this employee
	 * @param locale the locale of the language
	 */
	@Override
	public void setDesignation(String designation, java.util.Locale locale) {
		model.setDesignation(designation, locale);
	}

	/**
	 * Sets the localized designation of this employee in the language, and sets the default locale.
	 *
	 * @param designation the localized designation of this employee
	 * @param locale the locale of the language
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setDesignation(
		String designation, java.util.Locale locale,
		java.util.Locale defaultLocale) {

		model.setDesignation(designation, locale, defaultLocale);
	}

	@Override
	public void setDesignationCurrentLanguageId(String languageId) {
		model.setDesignationCurrentLanguageId(languageId);
	}

	/**
	 * Sets the localized designations of this employee from the map of locales and localized designations.
	 *
	 * @param designationMap the locales and localized designations of this employee
	 */
	@Override
	public void setDesignationMap(
		Map<java.util.Locale, String> designationMap) {

		model.setDesignationMap(designationMap);
	}

	/**
	 * Sets the localized designations of this employee from the map of locales and localized designations, and sets the default locale.
	 *
	 * @param designationMap the locales and localized designations of this employee
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setDesignationMap(
		Map<java.util.Locale, String> designationMap,
		java.util.Locale defaultLocale) {

		model.setDesignationMap(designationMap, defaultLocale);
	}

	/**
	 * Sets the employee ID of this employee.
	 *
	 * @param employeeId the employee ID of this employee
	 */
	@Override
	public void setEmployeeId(long employeeId) {
		model.setEmployeeId(employeeId);
	}

	/**
	 * Sets the employee name of this employee.
	 *
	 * @param employeeName the employee name of this employee
	 */
	@Override
	public void setEmployeeName(String employeeName) {
		model.setEmployeeName(employeeName);
	}

	/**
	 * Sets the localized employee name of this employee in the language.
	 *
	 * @param employeeName the localized employee name of this employee
	 * @param locale the locale of the language
	 */
	@Override
	public void setEmployeeName(String employeeName, java.util.Locale locale) {
		model.setEmployeeName(employeeName, locale);
	}

	/**
	 * Sets the localized employee name of this employee in the language, and sets the default locale.
	 *
	 * @param employeeName the localized employee name of this employee
	 * @param locale the locale of the language
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setEmployeeName(
		String employeeName, java.util.Locale locale,
		java.util.Locale defaultLocale) {

		model.setEmployeeName(employeeName, locale, defaultLocale);
	}

	@Override
	public void setEmployeeNameCurrentLanguageId(String languageId) {
		model.setEmployeeNameCurrentLanguageId(languageId);
	}

	/**
	 * Sets the localized employee names of this employee from the map of locales and localized employee names.
	 *
	 * @param employeeNameMap the locales and localized employee names of this employee
	 */
	@Override
	public void setEmployeeNameMap(
		Map<java.util.Locale, String> employeeNameMap) {

		model.setEmployeeNameMap(employeeNameMap);
	}

	/**
	 * Sets the localized employee names of this employee from the map of locales and localized employee names, and sets the default locale.
	 *
	 * @param employeeNameMap the locales and localized employee names of this employee
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setEmployeeNameMap(
		Map<java.util.Locale, String> employeeNameMap,
		java.util.Locale defaultLocale) {

		model.setEmployeeNameMap(employeeNameMap, defaultLocale);
	}

	/**
	 * Sets the gender of this employee.
	 *
	 * @param gender the gender of this employee
	 */
	@Override
	public void setGender(String gender) {
		model.setGender(gender);
	}

	/**
	 * Sets the localized gender of this employee in the language.
	 *
	 * @param gender the localized gender of this employee
	 * @param locale the locale of the language
	 */
	@Override
	public void setGender(String gender, java.util.Locale locale) {
		model.setGender(gender, locale);
	}

	/**
	 * Sets the localized gender of this employee in the language, and sets the default locale.
	 *
	 * @param gender the localized gender of this employee
	 * @param locale the locale of the language
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setGender(
		String gender, java.util.Locale locale,
		java.util.Locale defaultLocale) {

		model.setGender(gender, locale, defaultLocale);
	}

	@Override
	public void setGenderCurrentLanguageId(String languageId) {
		model.setGenderCurrentLanguageId(languageId);
	}

	/**
	 * Sets the localized genders of this employee from the map of locales and localized genders.
	 *
	 * @param genderMap the locales and localized genders of this employee
	 */
	@Override
	public void setGenderMap(Map<java.util.Locale, String> genderMap) {
		model.setGenderMap(genderMap);
	}

	/**
	 * Sets the localized genders of this employee from the map of locales and localized genders, and sets the default locale.
	 *
	 * @param genderMap the locales and localized genders of this employee
	 * @param defaultLocale the default locale
	 */
	@Override
	public void setGenderMap(
		Map<java.util.Locale, String> genderMap,
		java.util.Locale defaultLocale) {

		model.setGenderMap(genderMap, defaultLocale);
	}

	/**
	 * Sets the group ID of this employee.
	 *
	 * @param groupId the group ID of this employee
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the joining date of this employee.
	 *
	 * @param joiningDate the joining date of this employee
	 */
	@Override
	public void setJoiningDate(Date joiningDate) {
		model.setJoiningDate(joiningDate);
	}

	/**
	 * Sets the modified date of this employee.
	 *
	 * @param modifiedDate the modified date of this employee
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the primary key of this employee.
	 *
	 * @param primaryKey the primary key of this employee
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the user ID of this employee.
	 *
	 * @param userId the user ID of this employee
	 */
	@Override
	public void setUserId(long userId) {
		model.setUserId(userId);
	}

	/**
	 * Sets the user name of this employee.
	 *
	 * @param userName the user name of this employee
	 */
	@Override
	public void setUserName(String userName) {
		model.setUserName(userName);
	}

	/**
	 * Sets the user uuid of this employee.
	 *
	 * @param userUuid the user uuid of this employee
	 */
	@Override
	public void setUserUuid(String userUuid) {
		model.setUserUuid(userUuid);
	}

	/**
	 * Sets the uuid of this employee.
	 *
	 * @param uuid the uuid of this employee
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	public StagedModelType getStagedModelType() {
		return model.getStagedModelType();
	}

	@Override
	protected EmployeeWrapper wrap(Employee employee) {
		return new EmployeeWrapper(employee);
	}

}