/**
 * 
 */
package com.liferay.training.employee.exception;

import com.liferay.portal.kernel.exception.PortalException;

import java.util.List;

/**
 * @author DK00631421
 *
 */
public class EmployeeValidationException extends PortalException {
	
	public EmployeeValidationException() {
	}

	public EmployeeValidationException(String msg) {
		super(msg);
	}

	public EmployeeValidationException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public EmployeeValidationException(Throwable cause) {
		super(cause);
	}
	
	/**
	* Custom constructor taking a list as a parameter.
	*
	* @param errors
	*/
	public EmployeeValidationException(List<String> errors) {
		super(String.join(",", errors));
		_errors = errors;
	}
	public List<String> getErrors() {
		return _errors;
	}
	private List<String> _errors;

}//end class
