/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.employee.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.training.employee.model.Employee;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;
import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the remote service utility for Employee. This utility wraps
 * <code>com.liferay.training.employee.service.impl.EmployeeServiceImpl</code> and is an
 * access point for service operations in application layer code running on a
 * remote server. Methods of this service are expected to have security checks
 * based on the propagated JAAS credentials because this service can be
 * accessed remotely.
 *
 * @author devendra
 * @see EmployeeService
 * @generated
 */
@ProviderType
public class EmployeeServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.liferay.training.employee.service.impl.EmployeeServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */
	
	public static Employee addEmployee(long groupId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		
		return getService().addEmployee(groupId,employeeNameMap,genderMap,designationMap,descriptionMap,joiningDate,serviceContext);	
	}
	
	public static Employee deleteEmployee(long employeeId) throws PortalException {
		return getService().deleteEmployee(employeeId);
	}
	
	
	public static Employee getEmployee(
			long employeeId)
		throws PortalException {

		return getService().getEmployee(employeeId);
	}
	
	
	public static java.util.List<Employee>
		getEmployeesByGroupId(long groupId) {

		return getService().getEmployeesByGroupId(groupId);
	}
	
	
	
	public static java.util.List<Employee>
		getEmployeesByKeywords(
			long groupId, String keywords, int start, int end,
			com.liferay.portal.kernel.util.OrderByComparator
				<Employee>
					orderByComparator) {

		return getService().getEmployeesByKeywords(
			groupId, keywords, start, end, orderByComparator);
	}

	
	public static long getEmployeesCountByKeywords(long groupId, String keywords) {
		return getService().getEmployeesCountByKeywords(
			groupId, keywords);
	}
	
	
	public static Employee updateEmployee(long employeeId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		return getService().updateEmployee(employeeId, employeeNameMap,
				 genderMap, designationMap,descriptionMap,joiningDate,serviceContext);
	}
	
	
	
	

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	public static EmployeeService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<EmployeeService, EmployeeService>
		_serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(EmployeeService.class);

		ServiceTracker<EmployeeService, EmployeeService> serviceTracker =
			new ServiceTracker<EmployeeService, EmployeeService>(
				bundle.getBundleContext(), EmployeeService.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}

}