/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.employee.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.training.employee.model.Employee;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides a wrapper for {@link EmployeeService}.
 *
 * @author devendra
 * @see EmployeeService
 * @generated
 */
@ProviderType
public class EmployeeServiceWrapper
	implements EmployeeService, ServiceWrapper<EmployeeService> {

	public EmployeeServiceWrapper(EmployeeService employeeService) {
		_employeeService = employeeService;
	}
	
	
	@Override
	public Employee addEmployee(long groupId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		
		return _employeeService.addEmployee(groupId,employeeNameMap,genderMap,designationMap,descriptionMap,joiningDate,serviceContext);
		
	}
	
	@Override
	public Employee deleteEmployee(long employeeId) throws PortalException {
		return _employeeService.deleteEmployee(employeeId);
	}
	
	@Override
	public Employee getEmployee(
			long employeeId)
		throws PortalException {

		return _employeeService.getEmployee(employeeId);
	}
	
	@Override
	public java.util.List<Employee>
		getEmployeesByGroupId(long groupId) {

		return _employeeService.getEmployeesByGroupId(groupId);
	}
	
	
	@Override
	public java.util.List<Employee>
		getEmployeesByKeywords(
			long groupId, String keywords, int start, int end,
			com.liferay.portal.kernel.util.OrderByComparator
				<Employee>
					orderByComparator) {

		return _employeeService.getEmployeesByKeywords(
			groupId, keywords, start, end, orderByComparator);
	}

	@Override
	public long getEmployeesCountByKeywords(long groupId, String keywords) {
		return _employeeService.getEmployeesCountByKeywords(
			groupId, keywords);
	}
	
	@Override
	public Employee updateEmployee(long employeeId, Map<Locale, String> employeeNameMap,
			Map<Locale, String> genderMap,Map<Locale, String> designationMap,
			Map<Locale, String> descriptionMap, Date joiningDate, ServiceContext serviceContext) 
					throws PortalException{
		return _employeeService.updateEmployee(employeeId, employeeNameMap,
				 genderMap, designationMap,descriptionMap,joiningDate,serviceContext);
	}
	
	
	
	

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _employeeService.getOSGiServiceIdentifier();
	}

	@Override
	public EmployeeService getWrappedService() {
		return _employeeService;
	}

	@Override
	public void setWrappedService(EmployeeService employeeService) {
		_employeeService = employeeService;
	}

	private EmployeeService _employeeService;

}