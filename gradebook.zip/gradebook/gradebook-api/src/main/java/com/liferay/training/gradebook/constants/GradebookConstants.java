package com.liferay.training.gradebook.constants;

public class GradebookConstants {
	public static final String RESOURCE_NAME = "com.liferay.training.gradebook.model";
}
