/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.auth.PrincipalException;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.training.gradebook.model.Submission;
import com.liferay.training.gradebook.service.base.SubmissionServiceBaseImpl;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the submission remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.liferay.training.gradebook.service.SubmissionService</code> interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author hgrahul
 * @see SubmissionServiceBaseImpl
 */
@Component(
	property = {
		"json.web.service.context.name=gradebook",
		"json.web.service.context.path=Submission"
	},
	service = AopService.class
)
public class SubmissionServiceImpl extends SubmissionServiceBaseImpl {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Always use <code>com.liferay.training.gradebook.service.SubmissionServiceUtil</code> to access the submission remote service.
	 */
	
	public Submission addSubmission(long assignmentId, long studentId, String submissionText, ServiceContext serviceContext) throws PortalException {

		// Check permissions.
		//_assignmentModelResourcePermission.check(getPermissionChecker(), assignmentId, "ADD_SUBMISSION");
		
		return submissionLocalService.addSubmission(assignmentId, studentId, submissionText, serviceContext);
	}
	
	public Submission deleteSubmission(long submissionId)throws PortalException {
		// Check permissions.
		//Submission submission = submissionLocalService.getSubmission(submissionId);
		//_assignmentModelResourcePermission.check(getPermissionChecker(), submission.getAssignmentId(),"DELETE_SUBMISSION");
		
		return submissionLocalService.deleteSubmission(submissionId);
	}
	
	public Submission gradeSubmission(long submissionId, int grade) throws PortalException {
		// Check Permission
		//Submission submission = submissionLocalService.getSubmission(submissionId);
		//_assignmentModelResourcePermission.check(getPermissionChecker(), submission.getAssignmentId(),"GRADE_SUBMISSION");
		
		return submissionLocalService.gradeSubmission(submissionId, grade);
	}
	
	public Submission gradeAndCommentSubmission(long submissionId, int grade, String comment)throws PortalException {
		// Check Permission
		//Submission submission = submissionLocalService.getSubmission(submissionId);
		//_assignmentModelResourcePermission.check(getPermissionChecker(), submission.getAssignmentId(),"GRADE_SUBMISSION");

		return submissionLocalService.gradeAndCommentSubmission(submissionId, grade, comment);
	}
	
	public List<Submission> getSubmissionsByAssignment(long groupId, long assignmentId, int start, int end) throws PrincipalException, PortalException {
		// Check Permission
		//_assignmentModelResourcePermission.check(getPermissionChecker(), assignmentId, "VIEW_SUBMISSIONS");
		return submissionPersistence.findByG_A(groupId, assignmentId, start, end);
	}

	public int getSubmissionsCountByAssignment(long groupId, long assignmentId) {
		return submissionPersistence.countByG_A(groupId, assignmentId);
	}
	
	public Submission updateSubmission(long submissionId, String submissionText, ServiceContext serviceContext) throws PortalException {
		//Check Permission
		//Submission submission = submissionLocalService.getSubmission(submissionId);
		//_assignmentModelResourcePermission.check(getPermissionChecker(), submission.getAssignmentId(),"EDIT_SUBMISSION");
		return submissionLocalService.updateSubmission(submissionId, submissionText, serviceContext);
	}
	
	/**
	 * 
	 * @Reference(
	 * 		policy = ReferencePolicy.DYNAMIC,
	 *		policyOption = ReferencePolicyOption.GREEDY,
	 *		target = "(model.class.name=com.liferay.training.gradebook.model.Assignment)"
	 * 		)
	 * 		private volatile ModelResourcePermission<Assignment> _assignmentModelResourcePermission;
	 * 
	 */
}