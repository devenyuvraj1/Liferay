/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.training.gradebook.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.model.Submission;
import com.liferay.training.gradebook.service.base.SubmissionLocalServiceBaseImpl;

import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * The implementation of the submission local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the <code>com.liferay.training.gradebook.service.SubmissionLocalService</code> interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author hgrahul
 * @see SubmissionLocalServiceBaseImpl
 */
@Component(
	property = "model.class.name=com.liferay.training.gradebook.model.Submission",
	service = AopService.class
)
public class SubmissionLocalServiceImpl extends SubmissionLocalServiceBaseImpl {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Use <code>com.liferay.training.gradebook.service.SubmissionLocalService</code> via injection or a <code>org.osgi.util.tracker.ServiceTracker</code> or use <code>com.liferay.training.gradebook.service.SubmissionLocalServiceUtil</code>.
	 *//**
	* Adds a new submissions
	*
	* @param assignmentId
	* @param studentId
	* @param submissionText
	* @param serviceContext
	* @return
	* @throws PortalException
	*/
	@Override
	public Submission addSubmission(long assignmentId, long studentId, String submissionText, ServiceContext serviceContext) throws PortalException {
		Assignment assignment = assignmentPersistence.findByPrimaryKey(assignmentId);
		long userId = serviceContext.getUserId();

		// Verify that user exists (throws exception if not).
		User user = userLocalService.getUser(userId);
		
		// Verify that student exists (throws exception if not).
		User studentUser = userLocalService.getUser(studentId);

		// Validate submission
		//validateSubmission(serviceContext.getCompanyId(), studentId, assignment, -1L, submissionText);

		// Create submission id.
		long submissionId = counterLocalService.increment(Submission.class.getName());

		// Create new submission.
		Submission submission = submissionLocalService.createSubmission(submissionId);
		submission.setSubmissionId(submissionId);
		submission.setAssignmentId(assignmentId);
		submission.setCompanyId(assignment.getCompanyId());
		submission.setGroupId(assignment.getGroupId());
		submission.setCreateDate(new Date());
		submission.setModifiedDate(new Date());
		submission.setUserId(userId);
		submission.setGrade(-1);
		submission.setStudentId(studentId);
		submission.setSubmissionText(submissionText);
		submission.setSubmitDate(new Date());

		return super.addSubmission(submission);
	}
	
	@Override
	public Submission updateSubmission(long submissionId, String submissionText, ServiceContext serviceContext) throws PortalException {
		Submission submission = getSubmission(submissionId);
		Assignment assignment = assignmentPersistence.findByPrimaryKey(submission.getAssignmentId());

		// Validate submission
		//validateSubmission(serviceContext.getCompanyId(), submission.getStudentId(),assignment, submissionId, submissionText);

		submission.setSubmissionText(submissionText);
		submission.setSubmitDate(new Date());
		
		return super.updateSubmission(submission);
	}
	public List<Submission> getSubmissionsByAssignment(long groupId, long assignmentId) {
		return submissionPersistence.findByG_A(groupId, assignmentId);
	}
	public List<Submission> getSubmissionsByAssignment(long groupId, long assignmentId, int start, int end) {
		return submissionPersistence.findByG_A(groupId, assignmentId, start, end);
	}
	public int getSubmissionsCountByAssignment(long groupId, long assignmentId) {
		return submissionPersistence.countByG_A(groupId, assignmentId);
	}
	public Submission gradeSubmission(long submissionId, int grade) throws PortalException {
		Submission submission = getSubmission(submissionId);
		submission.setGrade(grade);
		submission.setModifiedDate(new Date());

		return super.updateSubmission(submission);
	}

	public Submission gradeAndCommentSubmission(long submissionId, int grade, String comment) throws PortalException {
		Submission submission = getSubmission(submissionId);
		submission.setGrade(grade);
		submission.setComment(comment);
		submission.setModifiedDate(new Date());
		return super.updateSubmission(submission);
	}
	
	/**
	 * 
	 * private void validateSubmission(long companyId, long studentId, Assignment assignment, long submissionId, String submissionText) throws PortalException, SubmissionValidationException, ConfigurationException {
	List<String> errorMessages = new ArrayList<String>();
	// Validate the due date.
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	String dueDate = sdf.format(assignment.getDueDate());
	String today = sdf.format(new Date());
	if (dueDate.compareTo(today) < 0) {
		errorMessages.add("submissionTooLate");
	}
	
	// Validate submission count.
	if (submissionId < 0) {
		long submissionCount = submissionPersistence.countByStudentIdAssignmentId(studentId, assignment.getAssignmentId());
		
		if (submissionCount > 0) {
			errorMessages.add("onlyOneSubmissionAllowed");
		}
	}
	else {
		Submission submission = submissionPersistence.fetchByPrimaryKey(submissionId);
		if (submission.getStudentId() != studentId) {
			errorMessages.add("onlyOneSubmissionAllowed");	
		}
	}

	// Validate text length.
	if (submissionText == null) {
		errorMessages.add("submissionTextNull");
	}
	
	// Throw an exception if necessary.
	if (errorMessages.size() > 0) {
		throw new SubmissionValidationException(errorMessages);
	}
}
	 * 
	 */
}